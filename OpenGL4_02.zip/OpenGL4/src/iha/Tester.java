package iha;

import frame.Window;

public class Tester {

	public static void main(String[] args) {
		new Window("ILDAR AKHMETOV First steps",500,500,60).Start();
	}
}
