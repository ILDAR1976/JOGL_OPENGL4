package moution;

public interface iMoutionBehavior {

}
