package rotate;

public interface iRotationBehavior {
	public void ReleaseMoving();
}
